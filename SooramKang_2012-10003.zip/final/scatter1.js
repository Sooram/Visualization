function row(d) { //row conversion function
    return { 
      country: d.Country,
      rankIdx: +d.IndexRank,
      index: +d.GlobalIndex,
      rankGdp: +d.GDPRank,
      gdp: +d.GDPPerCapita,
      region: d.Region
    }  
}

function callback(data) {
    console.log(data);
    //Basic setting
    var w = 800, h = 300;
    var margin = {top:20, right:300, bottom: 30, left: 30};
    var innerW = w - margin.right - margin.left,
        innerH = h - margin.top - margin.bottom;

    var svg = d3.select('#scatter1').append('svg')
        .attr('width', w)
        .attr('height', h)
        .append('g')
        .attr('transform', 'translate('+ [margin.left, margin.top] + ')');

    //Set x, y, and color scales
    var x = d3.scaleLinear() 
        .domain([0, d3.max(data, function(d) {return d.gdp})+10000]) 
        .range([0, innerW]);
    var y = d3.scaleLinear()
        .domain([0.5, 0.9])
        .range([innerH, 0]);
    var c = d3.scaleOrdinal()
        .domain(data.map(function(d){return d.region}))
        .range(d3.schemeCategory10);

    //Draw points
    var point = svg.selectAll('point')
        .data(data).enter()
        .append('g').attr('class', 'point')
        
    point.append('circle')
        .attr('cx', function(d) {return x(d.gdp)})
        .attr('cy', function(d) {return y(d.index)})
        .attr('r', 4)
        .attr('fill', function(d) {return c(d.region)})
        .attr('opacity', 0.5)

    point.append('text')
        .style('visibility', 'hidden')
        .attr('class', 'details')
        .attr('x', function(d) {return x(d.gdp)})
        .attr('y', function(d) {return y(d.index)})
        .text(function(d) {return d.country})
        .attr('font-size', 15)
    .append('svg:tspan')
        .style('visibility', 'hidden')
        .attr('class', 'details')
        .attr('x', function(d) {return x(d.gdp)})
        .attr('dy', 20)
        .text(function(d) { return 'GDPPC: ' + d.gdp; })
        .attr('font-size', 10)
    .append('svg:tspan')
        .style('visibility', 'hidden')
        .attr('class', 'details')
        .attr('x', function(d) {return x(d.gdp)})
        .attr('dy', 10)
        .text(function(d) { return 'index: ' + d.index; })
        .attr('font-size', 10);

    //Draw axis
    var xAxis = d3.axisBottom(x) 
        .tickSize(0) 
        .tickPadding(6); 
    var yAxis = d3.axisLeft(y)  
        .ticks(5)
        .tickSizeOuter(0)
    svg.append('g') 
        .attr('class', 'x axis')
        .attr('transform', 'translate(' + [0, innerH] + ')') 
        .call(xAxis);
    svg.append('g')
        .attr('class', 'y axis')
        .call(yAxis); 
    
    //Show details when a point is clicked
    point.on('click', function (d) {
        point.selectAll('.details')
            .style('visibility', 'hidden');
        point.selectAll('circle')
            .attr('r', 4)
            .attr('opacity', 0.5);
        d3.select(this).selectAll('.details')
            .style('visibility', 'visible');
        d3.select(this).select('circle')
            .attr('r', 6)
            .attr('opacity',1);
    });
    //+여백 클릭 시 원래대로
    //+포인트 클릭 시 레전드도 강조

    //Legend
    var chipHeight = 12; //레전드 안에 색상칩 크기
    var chipPadding = 2; //색상칩 간격
    var legendHeight = 16;
    var legendPadding = 4;
    var legend = svg.append('g')
        .attr('class', 'legend-g')
        .attr('transform', 'translate(' + [innerW + 50, legendHeight]  +  ')')
        .selectAll('.legend')
        .data(c.domain()) // 개별 색상이 legend 가 된다.
        .enter().append('g')
        .attr('class', 'legend')
        .attr('transform', function(d,i){
            return 'translate(' + [0, i *(legendHeight + legendPadding)]+ ')'
        })
    legend.append('rect')
        .attr('y', chipPadding)
        .attr('width', chipHeight).attr('height', chipHeight)
        .style('fill', function(d){return c(d)})
        .style('opacity', 0.5);

    legend.append('text')
        .attr('x', chipPadding + chipHeight)
        .attr('y', chipPadding)
        .attr('dy', '.71em')
        .style('font-size', 10+ 'px')
        .text(function(d){return d})
    //////////////////////////////////////////////////////////////////////////////////////
    var t = d3.transition()
        .duration(800)
        .ease(d3.easeElastic);

    var xy = d3.local();

    point.each(function(d) {
        xy.set(this, [x(d.gdp), y(d.index)]);
    })

    d3.select('.show').on('click', function(d) {
        var filtered = data.filter(d => d.gdp > 20000 && d.gdp < 40000);
        filtered = 
        console.log(filtered);

        //Set x domain again
        x.domain([15000, 45000]); 
           
        svg.select('.x.axis')
            .transition(t) 
            .call(xAxis);

        var circle = svg.selectAll('.point')
            .data(filtered).enter();
        console.log(circle);
        // circle.exit().remove();  

    //     point.each(function (d) {
    //         if(d.gdp > 20000 && d.gdp < 40000) {
    //             console.log(d.country + ' ' + d.gdp);
    //             xy.set(this, [x(d.gdp), y(d.index)]); 
    //         }
    //         else {
    //             console.log(this);
    //             d3.select(this).exit().remove();
    //             // xy.set(this, [0,0]);
    //         }
    //       }).transition(t)
    //       .attr('transform', function (d) { 
    //         return 'translate(' + xy.get(this) + ')'
    //       });
    })
}

d3.csv('/data/GDP-Index-Combined.csv', row).then(callback);